# Changelog

## v1.0.0 — 2026-11-06
- Created mobile-only Kotlin Android project.
- Added speech input, TTS response, limited offline command routing, app/settings launching, floating bubble, accessibility and notification-listener foundations.
- Documented incomplete features and Android permission constraints.
