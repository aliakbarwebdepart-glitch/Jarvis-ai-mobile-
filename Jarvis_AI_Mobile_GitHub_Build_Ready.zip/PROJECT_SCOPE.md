# Project Scope

Target device: Infinix X6817, Android 12.
Primary language: Urdu + English.
Preferred TTS: Male (best-effort; Android device voice availability controls actual voice).
Wake phrase requested: "Hey Jarvis" (planned; not implemented in v1.0).
PC RAM reported: 4 GB. PC functionality is intentionally excluded from this mobile-only package based on the user's latest scope clarification.

Architecture for future phases:
1. Android Kotlin client and permission-gated local actions.
2. On-device wake-word engine in a foreground service, with visible indicator and battery testing.
3. Cloud AI gateway (FastAPI) with allowlisted tool schema, authentication and rate limits.
4. Optional Supabase for account, opt-in memory and command logs.
5. Explicit confirmation gates for calls, messages, file deletion, purchases and other sensitive actions.
