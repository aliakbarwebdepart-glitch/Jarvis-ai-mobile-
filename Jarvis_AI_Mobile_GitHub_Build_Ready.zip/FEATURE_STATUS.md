# Jarvis Mobile Feature Status

| Feature | Status in v1.0 |
|---|---|
| Android native app shell | Included |
| Urdu/English speech input | Android system recognizer integration included; language availability depends on device/provider |
| Male voice | Not guaranteed; TTS voice selection depends on installed device voices |
| Basic spoken response | Included |
| Offline basic commands | Included (limited phrase rules) |
| App launch: WhatsApp/YouTube | Included |
| Camera/Gallery launch | Included |
| Wi-Fi/Bluetooth/Settings screens | Included |
| Back/Home/Recents | Accessibility skeleton included; user must enable service |
| Floating button | Included; user must grant overlay permission |
| Notification listener | Service skeleton included; no polished reader UI yet |
| WhatsApp compose | Included; user reviews and sends manually |
| Phone call | Dialer only; user confirms call |
| "Hey Jarvis" always-on wake word | Not included; planned, requires separate tested wake-word engine and foreground-service design |
| Continuous conversation | Not included in this build |
| Arbitrary in-app taps/typing | Not included |
| Cloud AI brain | Not included |
| Full long-term memory | Not included; only last command is stored locally |
| Supabase sync | Not included |
| Windows PC agent | Not included; current scope follows user's latest mobile-only instruction |
| Release APK | Not included; build locally using Android Studio |

This is an honest v1 starter implementation, not a claim that every advanced feature is complete.
