# Jarvis AI Mobile — v1.0 Starter Project

یہ Android-only ذاتی استعمال کا Kotlin project ہے، خاص طور پر Android 12 فون کے لیے۔ یہ ایک قابلِ تعمیر ابتدائی ایپ ہے، مکمل خودمختار AI یا ہر ایپ پر unrestricted control نہیں۔

## اس ZIP میں کیا ہے؟
- Native Android/Kotlin app project
- اردو/انگلش speech input کے لیے Android Speech Recognizer intent (زبان کی پہچان فون کے Speech Provider اور اس کی language settings پر منحصر ہے؛ Urdu اور English دونوں فون میں فعال رکھیں)
- Android Text-to-Speech جواب (مردانہ آواز فون میں دستیاب voice پر منحصر ہے)
- بنیادی Offline command router: Back، Home، Recents، Settings، Wi-Fi Settings، Bluetooth Settings، YouTube، WhatsApp، Camera، Gallery، Google Search، Dialer، WhatsApp share composer
- Accessibility Service کا ابتدائی ڈھانچہ
- Notification Listener کا ابتدائی ڈھانچہ
- Floating Jarvis bubble service
- آخری حکم محفوظ کرنے کے لیے local SharedPreferences
- Permissions اور setup documentation

## ابھی مکمل نہیں / اگلے مرحلے کے کام
- حقیقی "Hey Jarvis" always-on hotword engine شامل نہیں۔ Android 12 background microphone restrictions اور battery policies کی وجہ سے اس کے لیے الگ on-device wake-word engine، foreground service، واضح user opt-in اور device-specific testing درکار ہے۔
- Cloud LLM/API integration شامل نہیں؛ موجودہ command router محدود offline rules چلاتا ہے۔
- مکمل conversational memory، semantic search اور Supabase sync شامل نہیں۔
- Accessibility سے ہر app کے اندر arbitrary taps/typing کی automation ابھی شامل نہیں۔ یہ صرف Android global navigation actions اور settings/app launch کے لیے بنیاد فراہم کرتا ہے۔
- WhatsApp message صرف compose/share ہوتا ہے؛ خودکار ارسال نہیں ہوتا۔
- Calls کے لیے Dialer کھلتا ہے؛ کال صارف خود شروع کرتا ہے۔
- Notifications کا listener skeleton موجود ہے؛ UI میں notification inbox/reader ابھی نہیں۔
- APK اس ZIP میں شامل نہیں؛ اسے Android Studio سے build کرنا ہوگا۔

## Build کرنے کے لیے
1. کمپیوٹر پر Android Studio (تازہ stable) اور JDK 17 انسٹال کریں۔
2. Android Studio میں `android` فولڈر Open کریں۔
3. Gradle Sync مکمل ہونے دیں؛ Android SDK Platform 35 انسٹال ہونا چاہیے۔
4. اپنا Android 12 فون USB debugging کے ساتھ connect کریں، یا emulator منتخب کریں۔
5. Run دبائیں۔

## فون پر permissions فعال کرنا
- پہلی بار app کھولنے پر Microphone اجازت دیں۔
- Floating button کے لیے app کے اندر `Enable Floating Jarvis` دبائیں، پھر Android کی Display over other apps اجازت دیں، اور دوبارہ app میں آکر بٹن دبائیں۔
- Back/Home/Recents کے لیے `Enable Mobile Control` دبائیں اور Accessibility settings میں Jarvis AI کو خود فعال کریں۔
- Notification access صرف تب دیں جب واقعی ضرورت ہو۔ Notifications میں ذاتی پیغامات ہو سکتے ہیں؛ اس اجازت کو محدود رکھیں۔

## بنیادی voice commands
- "home" / "ہوم"
- "back" / "واپس"
- "recent apps" / "حالیہ ایپس"
- "settings" / "سیٹنگز"
- "wifi" / "وائی فائی"
- "bluetooth" / "بلوٹوتھ"
- "open WhatsApp" / "واٹس ایپ"
- "open YouTube" / "یوٹیوب"
- "camera" / "کیمرہ"
- "gallery" / "گیلری"
- "search weather" / "تلاش موسم"
- "call 03xxxxxxxxx" (صرف Dialer کھولے گا)
- "message Hello" (WhatsApp میں compose کرے گا؛ خود send نہیں کرے گا)

## Security
- کوئی arbitrary shell/ADB command executor نہیں ہے۔
- ادائیگی، پاس ورڈ، OTP یا خودکار پیغام ارسال کرنے کی automation نہیں ہے۔
- Accessibility اور Notification access طاقتور Android permissions ہیں؛ صرف اپنی مرضی سے فعال کریں۔
- کسی اکاؤنٹ کا password، OTP یا Supabase service-role key source code میں نہ ڈالیں۔
