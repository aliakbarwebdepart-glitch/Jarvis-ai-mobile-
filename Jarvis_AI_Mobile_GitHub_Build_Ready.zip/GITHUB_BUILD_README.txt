# Jarvis Android starter — GitHub Actions build

1. Extract this ZIP.
2. Create a new GitHub repository.
3. Upload the extracted contents (including the hidden `.github` folder) to the repository root.
4. Open the repository's Actions tab and run **Build Jarvis Android APK**.
5. When the run succeeds, download `Jarvis-AI-Mobile-APK` from Artifacts and extract `app-debug.apk`.

This is a starter Android project. The APK build does not add missing features automatically.
The current source does not yet implement a complete always-on wake word, full AI brain,
complete app automation, or cloud memory. Those require additional development and, for
online AI, configured service credentials. Never upload API keys or passwords to a public repo.
