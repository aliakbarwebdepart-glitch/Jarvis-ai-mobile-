# Build & Test Checklist

- [ ] Open `android/` in Android Studio
- [ ] Sync Gradle with JDK 17 and Android SDK 35
- [ ] Build Debug APK
- [ ] Install on Infinix X6817 / Android 12
- [ ] Grant microphone permission
- [ ] Test Urdu and English speech recognition
- [ ] Test Home, Back, Recents after enabling Accessibility
- [ ] Test Floating Button after granting overlay permission
- [ ] Test WhatsApp and YouTube launch
- [ ] Test camera and gallery launch
- [ ] Test Wi-Fi and Bluetooth settings launch
- [ ] Test Dialer only (do not auto-place calls)
- [ ] Test WhatsApp compose and manually review before sending
- [ ] Test notification listener only if user explicitly enables it
- [ ] Confirm the app can be stopped and permissions revoked from Android Settings

Do not treat the app as production-ready until device testing and remaining feature work are complete.
