package com.jarvis.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn?.notification ?: return
        val title = n.extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = n.extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isNotBlank() || body.isNotBlank()) {
            synchronized(recent) {
                recent.add(0, (title + ": " + body).trim())
                while (recent.size > 30) recent.removeAt(recent.lastIndex)
            }
        }
    }
    companion object { val recent: MutableList<String> = mutableListOf() }
}
