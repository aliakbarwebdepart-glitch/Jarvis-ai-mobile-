package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object CommandRouter {
    fun run(context: Context, raw: String): String {
        val q = raw.trim().lowercase()
        if (q.isBlank()) return "مجھے حکم سنائی نہیں دیا۔"
        val access = JarvisAccessibilityService.instance
        when {
            q.contains("back") || q.contains("واپس") || q.contains("پیچھے") -> { access?.goBack() ?: return "پہلے Accessibility Service فعال کریں۔"; return "واپس جا رہا ہوں۔" }
            q.contains("home") || q.contains("ہوم") -> { access?.goHome() ?: return "پہلے Accessibility Service فعال کریں۔"; return "Home screen کھول رہا ہوں۔" }
            q.contains("recent") || q.contains("حالیہ ایپس") -> { access?.openRecents() ?: return "پہلے Accessibility Service فعال کریں۔"; return "Recent apps کھول رہا ہوں۔" }
            q.contains("wifi") || q.contains("وائی فائی") -> { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Wi-Fi settings کھول دی ہیں۔" }
            q.contains("bluetooth") || q.contains("بلوٹوتھ") -> { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Bluetooth settings کھول دی ہیں۔" }
            q.contains("setting") || q.contains("سیٹنگ") -> { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Settings کھول دی ہیں۔" }
            q.contains("youtube") || q.contains("یوٹیوب") -> { openPackageOrWeb(context, "com.google.android.youtube", "https://www.youtube.com"); return "YouTube کھول رہا ہوں۔" }
            q.contains("whatsapp") || q.contains("واٹس ایپ") -> { openPackageOrWeb(context, "com.whatsapp", "https://www.whatsapp.com"); return "WhatsApp کھول رہا ہوں۔" }
            q.contains("camera") || q.contains("کیمرہ") -> { context.startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Camera کھول رہا ہوں۔" }
            q.contains("gallery") || q.contains("گیلری") || q.contains("photos") -> { context.startActivity(Intent(Intent.ACTION_VIEW).setType("image/*").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Gallery کھول رہا ہوں۔" }
            q.startsWith("search ") || q.startsWith("تلاش ") -> { val term = raw.substringAfter(' ').trim(); context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(term))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "$term تلاش کر رہا ہوں۔" }
            q.startsWith("call ") || q.startsWith("کال ") -> { val number = raw.substringAfter(' ').trim(); if (number.any { it.isDigit() }) { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Dialer کھول دیا ہے؛ کال آپ خود confirm کریں۔" } }
            q.startsWith("message ") || q.startsWith("میسج ") -> { val text = raw.substringAfter(' ').trim(); val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { context.startActivity(i); return "WhatsApp میں پیغام تیار ہے؛ بھیجنے سے پہلے خود چیک کریں۔" } catch (_: Exception) { return "WhatsApp دستیاب نہیں۔" } }
        }
        return "یہ حکم ابھی میرے بنیادی Offline Commands میں شامل نہیں۔ آپ اسے دوبارہ واضح الفاظ میں کہیں یا AI Cloud integration شامل کریں۔"
    }

    private fun openPackageOrWeb(context: Context, pkg: String, url: String) {
        val launch = context.packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
