package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var output: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private val voiceRequest = 701
    private val micRequest = 702

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        requestMic()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 32, 24, 24); setBackgroundColor(0xFF071426.toInt()) }
        val title = TextView(this).apply { text = "JARVIS AI"; textSize = 28f; setTextColor(0xFF64B5F6.toInt()); gravity = Gravity.CENTER; setPadding(0, 12, 0, 22) }
        val subtitle = TextView(this).apply { text = "Your personal voice assistant • اردو + English"; textSize = 14f; setTextColor(0xFFCFD8E3.toInt()); gravity = Gravity.CENTER; setPadding(0, 0, 0, 18) }
        input = EditText(this).apply { hint = "اپنا حکم لکھیں یا مائیک دبائیں"; setHintTextColor(0xFF90A4AE.toInt()); setTextColor(-1); setSingleLine(false) }
        val mic = makeButton("🎙  Speak / بولیں") { startVoice() }
        val send = makeButton("Send Command") { runCommand(input.text.toString()) }
        val float = makeButton("Enable Floating Jarvis") { enableFloating() }
        val accessibility = makeButton("Enable Mobile Control") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        val notifications = makeButton("Enable Notification Access") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        output = TextView(this).apply { text = "السلام علیکم! میں Jarvis ہوں۔\nمائیک دبائیں یا حکم لکھیں۔"; textSize = 16f; setTextColor(0xFFE3F2FD.toInt()); setPadding(12, 22, 12, 22) }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title); root.addView(subtitle); root.addView(input, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(mic); root.addView(send); root.addView(float); root.addView(accessibility); root.addView(notifications)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestMic(); return }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Jarvis کو حکم دیں / Speak to Jarvis")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { startActivityForResult(intent, voiceRequest) } catch (_: Exception) { speak("Speech recognition آپ کے فون پر دستیاب نہیں۔") }
    }

    @Deprecated("Deprecated by Android but supported for this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = matches?.firstOrNull().orEmpty()
            input.setText(spoken)
            runCommand(spoken)
        }
    }

    private fun runCommand(command: String) {
        if (command.isBlank()) return
        val result = CommandRouter.run(this, command)
        output.text = "آپ: $command\n\nJarvis: $result\n\n" + output.text
        getSharedPreferences("jarvis_memory", MODE_PRIVATE).edit().putString("last_command", command).apply()
        speak(result)
    }

    private fun enableFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else startService(Intent(this, FloatingAssistantService::class.java))
    }

    private fun requestMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ur", "PK"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.US)
            // The actual voice gender depends on voices installed on the Android device.
        }
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
